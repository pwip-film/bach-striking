<?php
/*
Plugin Name: Qode Instagram Widget
Description: Plugin that adds Instagram feed functionality to our theme
Author: Qode Themes
Version: 1.0
*/
define('QODE_INSTAGRAM_WIDGET_VERSION', '1.0');

include_once 'load.php';